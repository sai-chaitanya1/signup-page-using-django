from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth



def home(request):
	if request.method=="POST":
		username=request.POST['username']
		#phonenumber=request.POST['phonenumber']
		email=request.POST['email']
		password=request.POST['password']
		password1=request.POST['password1']
		if password==password1:
			if User.objects.filter(username=username).exists():
				print("Username taken")
			elif User.objects.filter(email=email).exists():
				print("email taken")
			else:
				user=User.objects.create_user(username=username, email=email, password=password)
				user.save();
				print('user created')
		else:
			print('password not matching')
		return redirect('/register')
	else:
		return render(request,'home.html')

